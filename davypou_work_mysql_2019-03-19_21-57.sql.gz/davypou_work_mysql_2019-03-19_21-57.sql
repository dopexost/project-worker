
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES binary */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `publicationDate` date NOT NULL,
  `title` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `content` mediumtext NOT NULL,
  `mails` text NOT NULL,
  `start_work` time NOT NULL,
  `end_work` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,'2017-05-04','Иванов Иван Иванович','Начальник АХО ','Принят на работу ','iva@gmail.com','10:00:00','19:00:00'),(2,'2016-11-06','Козачук Иван ','инженер I категории  службы поддрежки ','Принят на работу... ','kosachuk@gmail.com','10:00:00','19:00:00'),(17,'2018-01-10','Сидоров Иван ','начальник поддержки','Принят на работу ','sid@gmail.com','10:00:00','19:00:00'),(18,'2018-03-26','Петров Иван ','Менеджер II категории ','Принят на работу ','petrov@gmail.com','10:00:00','19:00:00');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `parser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `publicationDate` date NOT NULL,
  `text` text NOT NULL,
  `text_t` text NOT NULL,
  `text_p` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `parser` WRITE;
/*!40000 ALTER TABLE `parser` DISABLE KEYS */;
INSERT INTO `parser` VALUES (1,'2017-10-05','<div class=\"entry-description\">        <div><p>In the wake of the recent New Zealand mosque shooting, the Cybersecurity and Infrastructure Security Agency (CISA) advises users to watch out for possible malicious cyber activity seeking to capitalize on this tragic event. Users should exercise caution in handling emails related to the shooting, even if they appear to originate from trusted sources. Fraudulent emails often contain links or attachments that direct users to phishing or malware-infected websites. Emails requesting donations from duplicitous charitable organizations are also common after tragic events. Be wary of fraudulent social media pleas, calls, texts, donation websites, and door-to-door solicitations relating to the event.</p><p>To avoid becoming a victim of malicious activity, users and administrators should consider taking the following preventive measures:</p></div>  </div>','0','111'),(2,'2017-10-04','<div class=\"entry-description\">        <div><p>Intel has released security updates and recommendations to address vulnerabilities in multiple products. An attacker could exploit some of these vulnerabilities to take control of an affected system.</p><p>The Cybersecurity and Infrastructure Security Agency (CISA) encourages users and administrators to review the <a href=\"https://www.intel.com/content/www/us/en/security-center/default.html\">Intel Product Security Center Advisories</a> page, apply the necessary mitigations, and refer to software vendors for appropriate patches, when available.</p></div>  </div>','0','3'),(3,'2017-10-03','<div class=\"entry-description\">        <div><p>VMware has released security updates to address vulnerabilities affecting Workstation 14 and 15, and Horizon 6 and 7. An attacker could exploit some of these vulnerabilities to take control of an affected system.  </p><p>The Cybersecurity and Infrastructure Security Agency (CISA) encourages users and administrators to review VMware Security Advisories <a href=\"https://www.vmware.com/security/advisories/VMSA-2019-0002.html\">VMSA-2019-0002</a> and <a href=\"https://www.vmware.com/security/advisories/VMSA-2019-0003.html\">VMSA-2019-0003</a> and apply the necessary updates.</p></div>  </div>','0','3'),(4,'2017-10-03','<div class=\"entry-description\">        <div><p>Microsoft has released an update to address a vulnerability in Azure Linux Guest Agent. An attacker could exploit this vulnerability to obtain access to sensitive information.<br /><br />The Cybersecurity and Infrastructure Security Agency (CISA) encourages users and administrators to review the <a href=\"https://portal.msrc.microsoft.com/en-US/security-guidance/advisory/CVE-2019-0804\">Microsoft Security Advisory</a> and apply the necessary update.</p></div>  </div>','0','0'),(5,'2017-10-03','<div class=\"entry-description\">        <div><p>The Multi-State Information Sharing and Analysis Center (MS-ISAC) has released a security primer on TrickBot malware. TrickBot is a modular banking Trojan that targets users’ financial information and acts as a dropper for other malware. An attacker can leverage TrickBot’s modules to steal banking information, conduct system and network reconnaissance, harvest credentials, and achieve network propagation.</p><p>The Cybersecurity and Infrastructure Security Agency (CISA) encourages users and administrators to review MS-ISAC’s White Paper: <a href=\"https://www.cisecurity.org/white-papers/security-primer-trickbot/\">Security Primer – TrickBot</a> for more information and best practice recommendations.</p></div>  </div>','0','0'),(6,'2017-10-03','<div class=\"entry-description\">        <div><p>WordPress 5.1 and prior versions are affected by a vulnerability. An attacker could exploit this vulnerability to take control of an affected website.</p><p>The Cybersecurity and Infrastructure Security Agency (CISA) encourages users and administrators to review the <a href=\"https://wordpress.org/news/2019/03/wordpress-5-1-1-security-and-maintenance-release/\">WordPress Security and Maintenance Release</a> and upgrade to WordPress 5.1.1.</p></div>  </div>','0','0');
/*!40000 ALTER TABLE `parser` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `update_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `update_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio_work` text NOT NULL,
  `text_new` text NOT NULL,
  `public` text NOT NULL,
  `u_public` varchar(250) NOT NULL,
  `went_work` varchar(250) NOT NULL,
  `u_went_work` varchar(250) NOT NULL,
  `data_today` varchar(250) NOT NULL,
  `status` int(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `update_text` WRITE;
/*!40000 ALTER TABLE `update_text` DISABLE KEYS */;
INSERT INTO `update_text` VALUES (134,'Иванов Иван Иванович','ewewewdfd','03:02','','23:03','','19.03.2019',0),(135,'Иванов Иван Иванович','аавав','03:02','','','','19.03.2019',0),(136,'Козачук Иван ','rerere','04:00','','03:44','','19.03.2019',0),(137,'Козачук Иван ','sdsd','01:01','','','','19.03.2019',0),(138,'Сидоров Иван ','wewew','11:01','','','','19.03.2019',0),(139,'Иванов Иван Иванович','10','10:00','','','','19.03.2019',0),(140,'Сидоров Иван ','','10:00','','','','19.03.2019',0),(141,'Козачук Иван ','','10:00','','','','19.03.2019',0),(142,'Сидоров Иван ',' wewew  ','10:00','','13:12','','19.03.2019',0),(143,'Петров Иван ','fdfd','08:00','','','','19.03.2019',0),(144,'Сидоров Иван ','q','04:00','','','','19.03.2019',0),(145,'Сидоров Иван ','aaa','00:00','test','','test1','19.03.2019',0),(146,'Сидоров Иван ','e','10:10','test','','test1','19.03.2019',0),(147,'Козачук Иван ','t','10:00','','','','19.03.2019',0),(148,'Сидоров Иван ','','10:00','','','','19.03.2019',0),(149,'Петров Иван ','sdsdsdsdsdsdasdasdas','11:11','','','','19.03.2019',0),(150,'Сидоров Иван ','323232','11:22','','','','20.03.2019',0),(151,'Иванов Иван Иванович',' dsdsdsds  ','00:23','txs','05:00','','20.03.2019',0),(152,'Козачук Иван ','','09:00','','19:00','','20.03.2019',0);
/*!40000 ALTER TABLE `update_text` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'work_manager','9f4ecb0b6609b6a8afca9e33e77620ed','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

